function showLogin() {
    document.getElementById("login-form").style.left = "50px";
    document.getElementById("signup-form").style.left = "450px";
    document.getElementById("btn").style.left = "0";
}

function showSignup() {
    document.getElementById("login-form").style.left = "-400px";
    document.getElementById("signup-form").style.left = "50px";
    document.getElementById("btn").style.left = "110px";
}
